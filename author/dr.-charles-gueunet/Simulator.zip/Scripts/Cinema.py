
from paraview.simple import *
from paraview import coprocessing


#--------------------------------------------------------------
# Code generated from cpstate.py to create the CoProcessor.
# paraview version 5.5.2-1-g0aca7619ff

#--------------------------------------------------------------
# Global screenshot output options
imageFileNamePadding=0
rescale_lookuptable=False


# ----------------------- CoProcessor definition -----------------------

def CreateCoProcessor():
  def _CreatePipeline(coprocessor, datadescription):
    class Pipeline:
      # state file generated using paraview version 5.5.2-1-g0aca7619ff

      # ----------------------------------------------------------------
      # setup views used in the visualization
      # ----------------------------------------------------------------

      # trace generated using paraview version 5.5.2-1-g0aca7619ff

      #### disable automatic camera reset on 'Show'
      paraview.simple._DisableFirstRenderCameraReset()

      # Create a new 'Render View'
      renderView1 = CreateView('RenderView')
      renderView1.ViewSize = [1214, 860]
      renderView1.AxesGrid = 'GridAxes3DActor'
      renderView1.StereoType = 0
      renderView1.CameraPosition = [-0.27790096227773203, 11.738642837893074, 5.6090660982862115]
      renderView1.CameraFocalPoint = [-0.11988827388716161, -0.1001145802945777, 0.21626774935867968]
      renderView1.CameraViewUp = [-0.032171322486397896, -0.4146792936135899, 0.909398751625276]
      renderView1.CameraParallelScale = 18.81832570136931
      renderView1.Background = [0.32, 0.34, 0.43]
      renderView1.MaxClipBounds = [-30.01001739501953, 30.010058403015137, -30.01001739501953, 30.010058403015137, -30.01001739501953, 30.010058403015137]
      renderView1.LockBounds = 1

      # init the 'GridAxes3DActor' selected for 'AxesGrid'
      renderView1.AxesGrid.XTitleFontFile = ''
      renderView1.AxesGrid.YTitleFontFile = ''
      renderView1.AxesGrid.ZTitleFontFile = ''
      renderView1.AxesGrid.XLabelFontFile = ''
      renderView1.AxesGrid.YLabelFontFile = ''
      renderView1.AxesGrid.ZLabelFontFile = ''

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView1,
          filename='image_%t.png', freq=10, fittoscreen=1, magnification=1, width=1214, height=860, cinema={"composite":True, "floatValues":True, "noValues":False, "camera":"azimuth-elevation-roll", "phi":[12],"theta":[7], "roll":[1], "initial":{ "eye": [-0.277901,11.7386,5.60907], "at": [0,0,0], "up": [-0.0321713,-0.414679,0.909399] }, "tracking":{ "object":"particles" } })
      renderView1.ViewTime = datadescription.GetTime()

      # ----------------------------------------------------------------
      # restore active view
      SetActiveView(renderView1)
      # ----------------------------------------------------------------

      # ----------------------------------------------------------------
      # setup the data processing pipelines
      # ----------------------------------------------------------------

      # create a new 'PVD Reader'
      # create a producer from a simulation input
      particles = coprocessor.CreateProducer(datadescription, 'particles')

      # define target arrays of filters.
      coprocessor.AddArraysToCinemaTrack(particles, 'arraySelection', ['collision', 'velocity'])

      # create a new 'SPH Volume Interpolator'
      sPHVolumeInterpolator1 = SPHVolumeInterpolator(Input=particles,
          Source='Bounded Volume')
      sPHVolumeInterpolator1.DensityArray = 'collision'
      sPHVolumeInterpolator1.MassArray = 'None'
      sPHVolumeInterpolator1.CutoffArray = 'None'
      sPHVolumeInterpolator1.Kernel = 'SPHQuinticKernel'
      sPHVolumeInterpolator1.Locator = 'Static Point Locator'

      # init the 'SPHQuinticKernel' selected for 'Kernel'
      sPHVolumeInterpolator1.Kernel.SpatialStep = 0.1

      # init the 'Bounded Volume' selected for 'Source'
      sPHVolumeInterpolator1.Source.Origin = [-0.9998392721502525, -0.9999279446295348, -0.9999997701515202]
      sPHVolumeInterpolator1.Source.Scale = [1.999548008989834, 1.9997448044250619, 2.0]
      sPHVolumeInterpolator1.Source.Resolution = [30, 30, 10]

      # define target arrays of filters.
      coprocessor.AddArraysToCinemaTrack(sPHVolumeInterpolator1, 'arraySelection', ['collision', 'Shepard Summation', 'velocity'])

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView1'
      # ----------------------------------------------------------------

      # show data from sPHVolumeInterpolator1
      sPHVolumeInterpolator1Display = Show(sPHVolumeInterpolator1, renderView1)

      # get color transfer function/color map for 'ShepardSummation'
      shepardSummationLUT = GetColorTransferFunction('ShepardSummation')
      shepardSummationLUT.RGBPoints = [0.0, 0.231373, 0.298039, 0.752941, 10.204387664794922, 0.865003, 0.865003, 0.865003, 20.408775329589844, 0.705882, 0.0156863, 0.14902]
      shepardSummationLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'ShepardSummation'
      shepardSummationPWF = GetOpacityTransferFunction('ShepardSummation')
      shepardSummationPWF.Points = [0.0, 0.0, 0.5, 0.0, 20.408775329589844, 1.0, 0.5, 0.0]
      shepardSummationPWF.ScalarRangeInitialized = 1

      # trace defaults for the display properties.
      sPHVolumeInterpolator1Display.Representation = 'Volume'
      sPHVolumeInterpolator1Display.ColorArrayName = ['POINTS', 'Shepard Summation']
      sPHVolumeInterpolator1Display.LookupTable = shepardSummationLUT
      sPHVolumeInterpolator1Display.OSPRayScaleArray = 'Shepard Summation'
      sPHVolumeInterpolator1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      sPHVolumeInterpolator1Display.SelectOrientationVectors = 'None'
      sPHVolumeInterpolator1Display.ScaleFactor = 0.2
      sPHVolumeInterpolator1Display.SelectScaleArray = 'None'
      sPHVolumeInterpolator1Display.GlyphType = 'Arrow'
      sPHVolumeInterpolator1Display.GlyphTableIndexArray = 'None'
      sPHVolumeInterpolator1Display.GaussianRadius = 0.01
      sPHVolumeInterpolator1Display.SetScaleArray = ['POINTS', 'Shepard Summation']
      sPHVolumeInterpolator1Display.ScaleTransferFunction = 'PiecewiseFunction'
      sPHVolumeInterpolator1Display.OpacityArray = ['POINTS', 'Shepard Summation']
      sPHVolumeInterpolator1Display.OpacityTransferFunction = 'PiecewiseFunction'
      sPHVolumeInterpolator1Display.DataAxesGrid = 'GridAxesRepresentation'
      sPHVolumeInterpolator1Display.SelectionCellLabelFontFile = ''
      sPHVolumeInterpolator1Display.SelectionPointLabelFontFile = ''
      sPHVolumeInterpolator1Display.PolarAxes = 'PolarAxesRepresentation'
      sPHVolumeInterpolator1Display.ScalarOpacityUnitDistance = 0.16651700749819384
      sPHVolumeInterpolator1Display.ScalarOpacityFunction = shepardSummationPWF
      sPHVolumeInterpolator1Display.Slice = 5

      # init the 'PiecewiseFunction' selected for 'ScaleTransferFunction'
      sPHVolumeInterpolator1Display.ScaleTransferFunction.Points = [0.0, 0.0, 0.5, 0.0, 20.408775329589844, 1.0, 0.5, 0.0]

      # init the 'PiecewiseFunction' selected for 'OpacityTransferFunction'
      sPHVolumeInterpolator1Display.OpacityTransferFunction.Points = [0.0, 0.0, 0.5, 0.0, 20.408775329589844, 1.0, 0.5, 0.0]

      # init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
      sPHVolumeInterpolator1Display.DataAxesGrid.XTitleFontFile = ''
      sPHVolumeInterpolator1Display.DataAxesGrid.YTitleFontFile = ''
      sPHVolumeInterpolator1Display.DataAxesGrid.ZTitleFontFile = ''
      sPHVolumeInterpolator1Display.DataAxesGrid.XLabelFontFile = ''
      sPHVolumeInterpolator1Display.DataAxesGrid.YLabelFontFile = ''
      sPHVolumeInterpolator1Display.DataAxesGrid.ZLabelFontFile = ''

      # init the 'PolarAxesRepresentation' selected for 'PolarAxes'
      sPHVolumeInterpolator1Display.PolarAxes.PolarAxisTitleFontFile = ''
      sPHVolumeInterpolator1Display.PolarAxes.PolarAxisLabelFontFile = ''
      sPHVolumeInterpolator1Display.PolarAxes.LastRadialAxisTextFontFile = ''
      sPHVolumeInterpolator1Display.PolarAxes.SecondaryRadialAxesTextFontFile = ''

      # ----------------------------------------------------------------
      # setup color maps and opacity mapes used in the visualization
      # note: the Get..() functions create a new object, if needed
      # ----------------------------------------------------------------

      # ----------------------------------------------------------------
      # finally, restore active source
      SetActiveSource(sPHVolumeInterpolator1)
      # ----------------------------------------------------------------
    return Pipeline()

  class CoProcessor(coprocessing.CoProcessor):
    def CreatePipeline(self, datadescription):
      self.Pipeline = _CreatePipeline(self, datadescription)

  coprocessor = CoProcessor()
  # these are the frequencies at which the coprocessor updates.
  freqs = {'particles': [10, 10]}
  coprocessor.SetUpdateFrequencies(freqs)
  return coprocessor


#--------------------------------------------------------------
# Global variable that will hold the pipeline for each timestep
# Creating the CoProcessor object, doesn't actually create the ParaView pipeline.
# It will be automatically setup when coprocessor.UpdateProducers() is called the
# first time.
coprocessor = CreateCoProcessor()

#--------------------------------------------------------------
# Enable Live-Visualizaton with ParaView and the update frequency
coprocessor.EnableLiveVisualization(True, 1)

# ---------------------- Data Selection method ----------------------

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep"
    global coprocessor
    if datadescription.GetForceOutput() == True:
        # We are just going to request all fields and meshes from the simulation
        # code/adaptor.
        for i in range(datadescription.GetNumberOfInputDescriptions()):
            datadescription.GetInputDescription(i).AllFieldsOn()
            datadescription.GetInputDescription(i).GenerateMeshOn()
        return

    # setup requests for all inputs based on the requirements of the
    # pipeline.
    coprocessor.LoadRequestedData(datadescription)

# ------------------------ Processing method ------------------------

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep"
    global coprocessor

    # Update the coprocessor by providing it the newly generated simulation data.
    # If the pipeline hasn't been setup yet, this will setup the pipeline.
    coprocessor.UpdateProducers(datadescription)

    # Write output data, if appropriate.
    coprocessor.WriteData(datadescription);

    # Write image capture (Last arg: rescale lookup table), if appropriate.
    coprocessor.WriteImages(datadescription, rescale_lookuptable=rescale_lookuptable,
        image_quality=0, padding_amount=imageFileNamePadding)

    # Live Visualization, if enabled.
    coprocessor.DoLiveVisualization(datadescription, "localhost", 22222)
