#include "UtilsVTK.h"

#include <vtkDoubleArray.h>
#include <vtkNew.h>
#include <vtkPoints.h>

namespace Utils
{
void BuildVTKGrid(vtkPolyData* polydata, const std::vector<double>& positions)
{
  // create the points information
  vtkNew<vtkDoubleArray> pointArray;
  pointArray->SetNumberOfComponents(3);
  pointArray->SetArray(
      const_cast<double*>(positions.data()), static_cast<vtkIdType>(positions.size()), 1);
  vtkNew<vtkPoints> points;
  points->SetDataTypeToDouble();
  points->SetData(pointArray);
  polydata->SetPoints(points);

  // create the cells
  vtkIdType numCells = points->GetNumberOfPoints();
  polydata->Allocate(numCells*2);
  for (vtkIdType cell = 0; cell < numCells; cell++)
  {
    polydata->InsertNextCell(VTK_VERTEX, 1, &cell);
  }
}

} // end namespace Utils
