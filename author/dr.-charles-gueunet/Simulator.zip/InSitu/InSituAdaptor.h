#pragma once

#include <vector>

namespace Adaptor
{
  void Initialize(const char* script);
  void Finalize();
  void CoProcess(
      std::vector<double>& pos,
      std::vector<double>& velocity,
      std::vector<int>& collisions,
      double time,
      unsigned int timeStep);
}
