/**
 * Utils file to create and update conduit objects
 */

#include <conduit.hpp>

#include <vector>

namespace Utils
{
void BuildConduitDataDesc(conduit::Node& state, double time, long timeStep);

void BuildConduitDataStructure(conduit::Node& mesh, std::vector<double>& pos,
  std::vector<double>& velocity, std::vector<int>& collisions);
}
