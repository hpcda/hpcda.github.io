#include "InSituAdaptor.h"

#include "UtilsVTK.h"

#include <vtkCPDataDescription.h>
#include <vtkCPInputDataDescription.h>
#include <vtkCPProcessor.h>
#include <vtkCPPythonScriptPipeline.h>
#include <vtkNew.h>
#include <vtkPolyData.h>

namespace Adaptor
{
const char* InputName = "particles";

vtkCPProcessor* Processor = nullptr;
vtkPolyData* VTKGrid = nullptr;

//----------------------------------------------------------------------------
void BuildVTKDataStructures(const std::vector<double>& pos, const std::vector<double>& velocity,
  const std::vector<int>& collisions, vtkCPInputDataDescription* idd)
{
  if (VTKGrid == nullptr)
  {
    VTKGrid = vtkPolyData::New();
  }
  Utils::BuildVTKGrid(VTKGrid, pos);

  if (idd->IsFieldNeeded("velocity", vtkDataObject::POINT) == true)
  {
    Utils::UpdateVTKAttributes(VTKGrid, velocity, "velocity", 3);
  }
  if (idd->IsFieldNeeded("collision", vtkDataObject::POINT) == true)
  {
    Utils::UpdateVTKAttributes(VTKGrid, collisions, "collision", 1);
  }
}

//----------------------------------------------------------------------------
void Initialize(const char* script)
{
  if (Processor == nullptr)
  {
    Processor = vtkCPProcessor::New();
    Processor->Initialize();
  }
  else
  {
    Processor->RemoveAllPipelines();
  }

  if (VTKGrid == nullptr)
  {
    VTKGrid = vtkPolyData::New();
  }

  vtkNew<vtkCPPythonScriptPipeline> pipeline;
  pipeline->Initialize(script);
  Processor->AddPipeline(pipeline);
}

//----------------------------------------------------------------------------
void Finalize()
{
  if (Processor)
  {
    Processor->Delete();
    Processor = nullptr;
  }
  if (VTKGrid)
  {
    VTKGrid->Delete();
    VTKGrid = nullptr;
  }
}

//----------------------------------------------------------------------------
void CoProcess(std::vector<double>& pos, std::vector<double>& velocity,
  std::vector<int>& collisions, double time, unsigned int timeStep)
{
  vtkNew<vtkCPDataDescription> dataDescription;
  dataDescription->AddInput(InputName);
  dataDescription->SetTimeData(time, timeStep);

  if (Processor->RequestDataDescription(dataDescription) != 0)
  {
    vtkCPInputDataDescription* idd = dataDescription->GetInputDescriptionByName(InputName);
    BuildVTKDataStructures(pos, velocity, collisions, idd);
    idd->SetGrid(VTKGrid);
    Processor->CoProcess(dataDescription);
  }
}
}
