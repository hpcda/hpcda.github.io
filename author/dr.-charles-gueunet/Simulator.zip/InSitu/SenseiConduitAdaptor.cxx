#include "InSituAdaptor.h"
#include "UtilsConduit.h"

#include <ConduitDataAdaptor.h>
#include <ConfigurableAnalysis.h>

namespace Adaptor
{
static sensei::ConduitDataAdaptor* DataAdaptor;
static sensei::ConfigurableAnalysis* AnalysisAdaptor;

void Initialize(const char* script)
{
  DataAdaptor = sensei::ConduitDataAdaptor::New();
  AnalysisAdaptor = sensei::ConfigurableAnalysis::New();
  AnalysisAdaptor->Initialize(script);
}

void Finalize()
{
  AnalysisAdaptor->Finalize();
  AnalysisAdaptor->Delete();
  DataAdaptor->Delete();
}

void CoProcess(std::vector<double>& pos, std::vector<double>& velocity,
  std::vector<int>& collisions, double time, unsigned int timeStep)
{
  DataAdaptor->SetDataTimeStep(timeStep);
  DataAdaptor->SetDataTime(time);

  conduit::Node exec_params;
  Utils::BuildConduitDataStructure(exec_params, pos, velocity, collisions);
  DataAdaptor->SetNode(&exec_params);

  AnalysisAdaptor->Execute(DataAdaptor);
}
}
