/**
 * Utils file to create and update VTK objects
 */

#include <vtkAOSDataArrayTemplate.h>
#include <vtkPointData.h>
#include <vtkPolyData.h>

#include <vector>

namespace Utils
{
void BuildVTKGrid(vtkPolyData* polyData, const std::vector<double>& positions);

template<typename scalarType>
void UpdateVTKAttributes(
  vtkPolyData* polydata, const std::vector<scalarType>& array, const char* name, vtkIdType nbComp)
{
  if (polydata->GetPointData()->GetArray(name) == nullptr)
  {
    vtkNew<vtkAOSDataArrayTemplate<scalarType> > collisionData;
    collisionData->SetName(name);
    collisionData->SetNumberOfComponents(nbComp);
    collisionData->SetNumberOfTuples(static_cast<vtkIdType>(array.size() / nbComp));
    polydata->GetPointData()->AddArray(collisionData);
  }
  vtkAOSDataArrayTemplate<scalarType>* collisionData =
    vtkAOSDataArrayTemplate<scalarType>::SafeDownCast(polydata->GetPointData()->GetArray(name));

  collisionData->SetArray(
    const_cast<scalarType*>(array.data()), static_cast<vtkIdType>(array.size()), 1);
}

}
