#include "InSituAdaptor.h"

#include "UtilsVTK.h"

#include <VTKDataAdaptor.h>
#include <vtkSmartPointer.h>
#include <ConfigurableAnalysis.h>


namespace Adaptor
{
  // for some reason, using vtkNew or vtkSmartPointer here lead to runtime MPI error
  static sensei::VTKDataAdaptor* DataAdaptor;
  static sensei::ConfigurableAnalysis* AnalysisAdaptor;
  static vtkNew<vtkPolyData> Grid;

  void BuildVTKDataStructures(const std::vector<double>& pos, const std::vector<double>& velocity,
    const std::vector<int>& collisions)
  {
    Utils::BuildVTKGrid(Grid, pos);
    Utils::UpdateVTKAttributes(Grid, velocity, "velocity", 3);
    Utils::UpdateVTKAttributes(Grid, collisions, "collision", 1);
  }

  void Initialize(const char* script)
  {
    DataAdaptor = sensei::VTKDataAdaptor::New();
    AnalysisAdaptor  = sensei::ConfigurableAnalysis::New();
    AnalysisAdaptor->Initialize(script);
  }

  void Finalize()
  {
    AnalysisAdaptor->Finalize();
    AnalysisAdaptor->Delete();
    DataAdaptor->Delete();
  }

  void CoProcess(
      std::vector<double>& pos,
      std::vector<double>& velocity,
      std::vector<int>& collisions,
      double time,
      unsigned int timeStep)
  {
    BuildVTKDataStructures(pos, velocity, collisions);
    DataAdaptor->SetDataTimeStep(timeStep);
    DataAdaptor->SetDataTime(time);
    DataAdaptor->SetDataObject("res", Grid);

    AnalysisAdaptor->Execute(DataAdaptor);
  }
}
