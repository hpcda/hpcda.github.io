#include "UtilsConduit.h"

#include <numeric>

namespace Utils
{

void BuildConduitDataDesc(conduit::Node& state, double time, long timeStep)
{
  state["timestep"].set(timeStep);
  state["time"].set(time);
}

void BuildConduitDataStructure(conduit::Node& mesh, std::vector<double>& pos,
  std::vector<double>& velocity, std::vector<int>& collisions)
{
  mesh["coordsets/coords/type"].set("explicit");

  mesh["coordsets/coords/values/x"].set_external(
    pos.data(), pos.size(), /*offset=*/0, /*stride=*/3 * sizeof(double));
  mesh["coordsets/coords/values/y"].set_external(
    pos.data(), pos.size(), /*offset=*/sizeof(double), /*stride=*/3 * sizeof(double));
  mesh["coordsets/coords/values/z"].set_external(
    pos.data(), pos.size(), /*offset=*/2 * sizeof(double), /*stride=*/3 * sizeof(double));

  mesh["topologies/mesh/type"].set("unstructured");
  mesh["topologies/mesh/coordset"].set("coords");
  mesh["topologies/mesh/elements/shape"].set("point");
  std::vector<int> vertices(pos.size() / 3);
  std::iota(std::begin(vertices), std::end(vertices), 0);
  mesh["topologies/mesh/elements/connectivity"].set_external(vertices.data(), vertices.size());

  // Finally, add fields.
  auto& fields = mesh["fields"];
  fields["velocity/association"].set("vertex");
  fields["velocity/topology"].set("mesh");
  fields["velocity/volume_dependent"].set("false");

  // velocity is stored in non-interlaced form (unlike points).
  fields["velocity/values/x"].set_external(
    velocity.data(), velocity.size(), /*offset=*/0, /*stride=*/3 * sizeof(double));
  fields["velocity/values/y"].set_external(
    velocity.data(), velocity.size(), /*offset=*/sizeof(double), /*stride*/ 3 * sizeof(double));
  fields["velocity/values/z"].set_external(
    velocity.data(), velocity.size(), /*offset=*/2 * sizeof(double), /*stride*/ 3 * sizeof(double));

  // pressure is cell-data.
  fields["collisions/association"].set("element");
  fields["collisions/topology"].set("mesh");
  fields["collisions/volume_dependent"].set("false");
  fields["collisions/values"].set_external(collisions.data(), collisions.size());
}

} // end namespace Utils
