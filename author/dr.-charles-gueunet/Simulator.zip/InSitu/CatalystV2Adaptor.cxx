#include "InSituAdaptor.h"
#include "UtilsConduit.h"

#include <catalyst.h>
#include <conduit_cpp_to_c.hpp>

#include <numeric>
#include <string>

namespace Adaptor
{

/**
 * In this example, we show how we can use Conduit's C++ API to
 * create Conduit nodes. This is not required. A C++ adaptor
 * can just as conveniently use the Conduit C API to setup
 * the `conduit_node`. However, this example shows that one can indeed
 * use the C++ API, if the developer so chooses.
 */

void Initialize(const char* script)
{
  conduit::Node node;
  node["catalyst/scripts/script"].set_string(script);
  catalyst_initialize(conduit::c_node(&node));
}

void CoProcess(std::vector<double>& pos,
               std::vector<double>& velocity,
               std::vector<int>& collisions,
               double time,
               unsigned int timeStep)
{
  conduit::Node exec_params;
  Utils::BuildConduitDataDesc(exec_params["catalyst/state"], time, timeStep);

  auto& channel = exec_params["catalyst/channels/particles"];
  channel["type"].set("mesh");
  Utils::BuildConduitDataStructure(channel["data"], pos, velocity, collisions);

  catalyst_execute(conduit::c_node(&exec_params));
}

void Finalize()
{
  conduit::Node node;
  catalyst_finalize(conduit::c_node(&node));
}
}
