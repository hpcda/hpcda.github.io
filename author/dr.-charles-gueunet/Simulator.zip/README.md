# Template code for projects.

Note that PV 5.6 build failed on mpi4py with recent python (e.g. python 3.8)
=======
# Simple particle simulation

This code initialize a set of points with random initial speed and position.
Then it simulates the movement of those particles inside a box under gravity,
handling collisions with a bounding box and loss of energy.

# Runing

`./simulator [options] <script>`

* `-d` N : the delay to wait between each timesteps, in milliseconds. Default 0.
* `-h` : show this help.
* `-p` N : the number of particles. Default 1000.
* `-t` N : the number of timesteps to process. Default 100.
* `-v` : active verbose mode.
* script : mandatory with catalyst, the python script to use for data processing.
